<?php

defined('MOODLE_INTERNAL') || die;

$plugin->version = 2021090220.38;
$plugin->requires  = 2018051700;
$plugin->component = 'block_cocoon_hero_4';
