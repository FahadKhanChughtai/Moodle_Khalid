<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2021090220.38; // The current plugin version (Date: YYYYMMDDXX).
$plugin->requires  = 2017111300; // Requires this Moodle version.
$plugin->component = 'block_cocoon_featured_teacher'; // Full name of the plugin (used for diagnostics).
