<?php

$string['cocoon_featured_teacher:addinstance'] = 'Add a [Cocoon] Featured Instructor block';
$string['cocoon_featured_teacher:myaddinstance'] = 'Add a [Cocoon] Featured Instructor to my moodle';
$string['pluginname'] = '[Cocoon] Featured Instructor';
