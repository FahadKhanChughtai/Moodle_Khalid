<?php
$string['pluginname'] = '[Cocoon] Simple Counters';
$string['cocoon_simple_counters'] = '[Cocoon] Simple Counters';
$string['cocoon_simple_counters:addinstance'] = 'Add a new Gallery block';
$string['cocoon_simple_counters:myaddinstance'] = 'Add a new Gallery block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_lectures'] = 'Lectures';
$string['config_quizzes'] = 'Quizzes';
$string['config_duration'] = 'Duration';
$string['config_skill_level'] = 'Skill level';
$string['config_language'] = 'Language';
$string['config_assessments'] = 'Assessments';
