<?php
$string['pluginname'] = '[Cocoon] Course Features Advanced';
$string['cocoon_course_feat_a'] = '[Cocoon] Course Features Advanced';
$string['cocoon_course_feat_a:addinstance'] = 'Add a new Course Features block';
$string['cocoon_course_feat_a:myaddinstance'] = 'Add a new Course Features block to the My Moodle page';
$string['config_title'] = 'Title';
