<?php
$string['pluginname'] = '[Cocoon] Course Info';
$string['cocoon_course_info'] = '[Cocoon] Course Info';
$string['cocoon_course_info:addinstance'] = 'Add a new Course Info block';
$string['cocoon_course_info:myaddinstance'] = 'Add a new Course Info block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_body'] = 'Body';
$string['config_image'] = 'Image';
