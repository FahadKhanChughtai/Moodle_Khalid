<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2021100102.25;
$plugin->requires  = 2018051700;
$plugin->component = 'block_cocoon_accordion';
