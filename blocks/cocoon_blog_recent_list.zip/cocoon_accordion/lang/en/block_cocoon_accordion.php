<?php

$string['configtitle'] = 'Block title';
$string['cocoon_accordion:addinstance'] = 'Add a new [Cocoon] Accordion block';
$string['cocoon_accordion:myaddinstance'] = 'Add a new [Cocoon] Accordion to Dashboard';
$string['pluginname'] = '[Cocoon] Accordion';
