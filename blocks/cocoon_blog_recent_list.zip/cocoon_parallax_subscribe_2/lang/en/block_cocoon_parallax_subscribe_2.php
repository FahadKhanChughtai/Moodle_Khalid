<?php
$string['pluginname'] = '[Cocoon] Parallax Subscribe 2';
$string['cocoon_parallax_subscribe_2'] = '[Cocoon] Parallax Subscribe 2';
$string['cocoon_parallax_subscribe_2:addinstance'] = 'Add a [Cocoon] Parallax Subscribe block 2';
$string['cocoon_parallax_subscribe_2:myaddinstance'] = 'Add a new [Cocoon] Parallax Subscribe 2 block to the My Moodle page';
