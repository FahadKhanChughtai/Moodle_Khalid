<?php
$string['pluginname'] = '[Cocoon] Featured Event';
$string['cocoon_featured_event'] = '[Cocoon] Featured Event';
$string['cocoon_featured_event:addinstance'] = 'Add a new Gallery block';
$string['cocoon_featured_event:myaddinstance'] = 'Add a new Gallery block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_body'] = 'Body';
$string['config_date'] = 'Date';
$string['config_time'] = 'Time';
$string['config_location'] = 'Location';
$string['config_image'] = 'Image';
