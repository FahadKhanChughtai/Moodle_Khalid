<?php
$string['cocoon_event_list:addinstance'] = 'Add a new block';
$string['cocoon_event_list:myaddinstance'] = 'Add a new block';
$string['pluginname'] = '[Cocoon] Event list';
