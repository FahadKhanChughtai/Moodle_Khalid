<?php
$string['pluginname'] = '[Cocoon] Event Contact';
$string['cocoon_event_contact'] = '[Cocoon] Event Contact';
$string['cocoon_event_contact:addinstance'] = 'Add a new Gallery block';
$string['cocoon_event_contact:myaddinstance'] = 'Add a new Gallery block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_phone'] = 'Phone';
$string['config_email'] = 'Email';
$string['config_website'] = 'Website';
$string['config_map_lat'] = 'Map latitude';
$string['config_map_lng'] = 'Map longitude';
