<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2021083018.38;
$plugin->requires  = 2017111300;
$plugin->component = 'block_cocoon_course_grid_4';
