<?php

$string['cocoon_cf_paid:addinstance'] = 'Add a new [Cocoon] Course Filter (Paid) block';
$string['cocoon_cf_paid:myaddinstance'] = 'Add a new [Cocoon] Course Filter (Paid) block to Dashboard';
$string['pluginname'] = '[Cocoon] Course Filter (Paid)';
