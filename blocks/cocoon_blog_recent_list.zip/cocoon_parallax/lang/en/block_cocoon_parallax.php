<?php
$string['pluginname'] = '[Cocoon] Parallax';
$string['cocoon_parallax'] = '[Cocoon] Parallax';
$string['cocoon_parallax:addinstance'] = 'Add a new Gallery block';
$string['cocoon_parallax:myaddinstance'] = 'Add a new Gallery block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_subtitle'] = 'Subtitle';
$string['config_button_text'] = 'Button text';
$string['config_button_link'] = 'Button link';
$string['config_image'] = 'Image';
